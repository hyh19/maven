package ${package}.dao;

public class Dao
{
}